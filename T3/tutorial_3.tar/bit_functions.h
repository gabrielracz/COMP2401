#include <stdio.h>


int isBitSet(unsigned char c, int bitNum);

unsigned char setBit(unsigned char c, int bitNum);

unsigned char clearBit(unsigned char c, int bitNum);

void printBitsIterative(unsigned char c);

void printBitsRecursive(unsigned char c);



