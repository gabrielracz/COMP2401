#ifndef MYSTAT_HEADER
#define MYSTAT_HEADER

void average(float *arr, int size, float *average);

#endif
